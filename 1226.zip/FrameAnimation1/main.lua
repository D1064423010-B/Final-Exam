-- 
-- Abstract: Bouncing fruit, using enterFrame listener for animation
-- 
-- Version: 1.3 (uses new viewableContentHeight, viewableContentWidth properties)
-- 
-- Sample code is MIT licensed, see http://www.coronalabs.com/links/code/license
-- Copyright (C) 2010 Corona Labs Inc. All Rights Reserved.

-- Demonstrates a simple way to perform animation, using an "enterFrame" listener to trigger updates.
--
-- Supports Graphics 2.0
------------------------------------------------------------

local xpos = display.contentCenterX
local ypos = display.contentCenterY
local baseline = 280

local background3 = display.newImage( "bg.jpg", xpos, ypos )
background3.xScale = .6
background3.yScale = .5

local background4 = display.newImage( "wwf.png", xpos, ypos )


local backgroundMusic =audio.loadStream("music.mp3")
audio.play(backgroundMusic,{channel=1,loops=-1,fadein=5000})

local sheet1 = graphics.newImageSheet( "he.png", { width=227, height=240.33, numFrames=18 } )
-- play 8 frames every 1000 ms
local instance1 = display.newSprite( sheet1, { name="bigtext", start=1, count=18, time=3000 } )
instance1.x = display.contentWidth / 4 + 78
instance1.y = baseline - 50
--instance1.xScale = .9
--instance1.yScale = .9
instance1:play()



local sheet2 = graphics.newImageSheet( "sn.png", { width=254, height=450, numFrames=35 } )
-- play 8 frames every 1000 ms
local instance2 = display.newSprite( sheet2, { name="snow", start=1, count=35, time=3000} )
instance2.x = display.contentWidth / 4 + 80
instance2.y = baseline -30
--instance2.xScale = .9
--instance2.yScale = .9
instance2:play()


local sheet3 = graphics.newImageSheet( "pig2.png", { width=257, height=452, numFrames=4 } )
-- play 8 frames every 1000 ms
local instance3 = display.newSprite( sheet3, { name="pig2", start=1, count=4, time=3000} )
instance3.x = display.contentWidth / 4 + 80
instance3.y = baseline -30
--instance3.xScale = .9
instance3.yScale = .7
instance3:play()

local sheet4 = graphics.newImageSheet( "text2.png", { width=258, height=454, numFrames=6 } )
-- play 8 frames every 1000 ms
local instance4 = display.newSprite( sheet4, { name="text2", start=1, count=6, time=3000} )
instance4.x = display.contentWidth / 4 + 75
instance4.y = baseline -85
--instance4.xScale = .9
--instance4.yScale = .7
instance4:play()
